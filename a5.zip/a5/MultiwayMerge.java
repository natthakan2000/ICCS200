import sun.awt.image.ImageWatched;

import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.PriorityQueue;
public class MultiwayMerge {
    public static LinkedList<Integer> mergeAll(LinkedList<Integer>[] lists){
        LinkedList<Integer> ans = new LinkedList<>();
        int sum = 0;
        PriorityQueue<LinkedList<Integer>> q = new PriorityQueue<>(Comparator.comparing(LinkedList<Integer>::peek));
        for(int i = 0; i < lists.length; i++){
            q.add(lists[i]);
            sum += lists[i].size();
        }
        //int counter = 0;
        while (sum > 0){
            if (q.peek() != null) {
                LinkedList<Integer> store = q.poll();
                ans.add(store.poll());
                if (!store.isEmpty()) {
                    q.add(store);
                }
                sum--;
            }
        }
        return ans;
    }
}
