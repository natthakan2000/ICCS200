public class DoubleTrouble {
    //Collarborators: Parm and Harvey
    public static int rank(int[] A, int[] B, int e) {
        int low = 0;
        int high = A.length;
        int high2 = B.length;
        return  rankHelper(A,low,high,e) + rankHelper(B,low,high2,e); //O(log(n+m))
    }
    public static int rankHelper(int[] A, int low, int high, int e){
        if(low == high){
            return low;
        }else {
            int m = (low + high)/2;
            if(A[m] < e){
                return rankHelper(A,m+1,high,e);
            }else{
                return rankHelper(A,low,m,e);
            }
        }
    }
    public static Integer select(int[] A, int[] B, int k) {
        int totalsize = A.length+B.length-1; //let length of a be n and length of b be m
        if(totalsize<k || k<0){
            return null;
        }else{
            Integer rankA = selectHelper(A,B,k,0,A.length-1,A); //O(log(n)log(n+m))
            if(rankA!=null){
                return rankA;
            }else return selectHelper(A,B,k,0,B.length-1,B); //O(log(m)log(n+m))
        }
    }
    public static Integer selectHelper(int[] A, int[] B, int k, int low, int high, int[] search){
        if(low>=high){
            if(rank(A,B,search[low])==k) {
                return search[low];
            }else return null;
        }else{
            int mid = (high+low)/2;
            int midrank = rank(A,B,search[mid]);
            if(midrank<k){
                return selectHelper(A, B, k,mid+1, high, search);
            }else{
                return selectHelper(A, B, k, low, mid, search);
            }
        }
    }
}
