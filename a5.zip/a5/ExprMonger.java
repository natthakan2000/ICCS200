import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
//Collaborators: Parm, Harvey, Taem, Nonnie, P Pao;
public class ExprMonger {
    public static double evalFullyParenthesized(List<String> tokens){
        Stack <String > ops = new Stack <>();
        Stack <Double > vals = new Stack<>();
        for (String tok : tokens){
            switch (tok){
                case "(":
                    ;
                    break;
                case "+":
                    ops.push(tok);
                    break;
                case "-":
                    ops.push(tok);
                    break;
                case "*":
                    ops.push(tok);
                    break;
                case "/":
                    ops.push(tok);
                    break;
                case "**":
                    ops.push(tok);
                    break;
                case ")":
                    String op = ops.pop();
                    double v = vals.pop();
                    double u = vals.pop();
                    vals.push(operator(u, op, v));
                    break;
                default:
                    vals.push(Double.parseDouble(tok));
                    break;
            }
        }
        return vals.peek();
    }
    static double operator(double u, String op , double v){
        switch (op) {
            case "+":
                return u + v;
            case "-":
                return u - v;
            case "*":
                return u * v;
            case "/":
                return u / v;
            case "**":
                return Math.pow(u, v);
            default:
                return Double.NaN;
        }
    }
    public static List<String> augmentExpr(List<String> tokens){
        Stack<String> operators  = new Stack <>();
        Stack<String> values = new Stack <>();
        for(String token : tokens) {
            switch (token) {
                case "(":
                    operators.push(token);
                    break;
                case "+":
                    pushBIDMAS(operators, values, token);
                    break;
                case "-":
                    pushBIDMAS(operators, values, token);
                    break;
                case "*":
                    pushBIDMAS(operators, values, token);
                    break;
                case "/":
                    pushBIDMAS(operators, values, token);
                    break;
                case "**":
                    pushBIDMAS(operators, values, token);
                    break;
                case ")":
                    while (!operators.peek().equals("(")) {
                        String values2 = values.pop();
                        String values1 = values.pop();
                        String operator = operators.pop();
                        String checking = combine(operator, values1, values2);
                        values.push(checking);
                    }
                    operators.pop();
                    break;
                default:
                    values.push(token);
                    break;
            }
        }
        List<String> newTokens = new ArrayList<>();
        if(operators.isEmpty()){
            newTokens.add(values.pop());
            return newTokens;
        }
        while(!operators.isEmpty()){
            String val2 = values.pop();
            String val1 = values.pop();
            String op = operators.pop();
            String ans = "("+val1+op+val2+")";
            values.push(ans);
        }
        newTokens = Utils.tokenize(values.pop());
        return newTokens;
    }
    public static void pushBIDMAS(Stack<String> operators, Stack<String> values, String operand){
        if(operators.isEmpty()||operators.peek().equals("(")){
            operators.push(operand);
            return;
        }
        String ontop = operators.pop();
        if(operand.equals("*")||operand.equals("/")){
            if(ontop.equals("+")||ontop.equals("-")){
                operators.push(ontop);
                operators.push(operand);
                return;
            }else{
                String val2 = values.pop();
                String val1 = values.pop();
                values.push(combine(ontop, val1, val2));
                operators.push(operand);
                return;
            }
        }
        if(operand.equals("**")){
            operators.push(ontop);
            operators.push(operand);
            return;
        }
        if(operand.equals("+")||operand.equals("-")){
            String val2 = values.pop();
            String val1 = values.pop();
            values.push(combine(ontop, val1, val2));
            operators.push(operand);
            return;
        }

    }
    public static String combine(String op, String val1, String val2){
        switch (op) {
            case "+":
                return "(" + val1 + "+" + val2 + ")";
            case "-":
                return "(" + val1 + "-" + val2 + ")";
            case "*":
                return "(" + val1 + "*" + val2 + ")";
            case "/":
                return "(" + val1 + "/" + val2 + ")";
            case "**":
                return "(" + val1 + "**" + val2 + ")";
            default:
                return "";
        }
    }
    public static double evalExpr(List<String> tokens) {
        List<String> fullyParenthesized = augmentExpr(tokens);
        return evalFullyParenthesized(fullyParenthesized);
    }
}
