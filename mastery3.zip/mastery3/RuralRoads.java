import java.lang.reflect.Array;
import java.util.*;
import graph.WeightedEdge;
import static graph.WeightedEdge.Edge;

public class RuralRoads {
    public static int totalWeight(List<WeightedEdge> edges) {
        PriorityQueue<int[]> compareWeight = new PriorityQueue<>(Comparator.comparing(x -> x[0]));
        List<Integer> union = new ArrayList<>();
        //List<int[]> union2 = new ArrayList<>();
        //PriorityQueue<int[]> compareWeight2 = new PriorityQueue<>();
        for (int i = 0; i < edges.size(); i++) {
            int[] edge = new int[3];
            edge[0] = edges.get(i).cost;
            edge[1] = edges.get(i).first;
            edge[2] = edges.get(i).second;
            compareWeight.add(edge);
        }
        long ans = 0;
        while (!compareWeight.isEmpty()){
            int[] check = compareWeight.poll();
            //union.add(check[2]);
            if (union.contains(check[2])){
                continue;
            }
            ans+=check[0];
            //union.add(check[1]);
            union.add(check[2]);
            //union2.add(check[0]);
        }
        //for (int i = 0; i < edges.size(); i++) {
          //  compareWeight.add(edges.get(i));
        //}
        //System.out.println(ans);
        return (int)ans;
    }


    public static void main(String[] args) {
       List<WeightedEdge> edges = new ArrayList<>(Arrays.asList(
            Edge(0, 1, 7),
            Edge(0, 3, 5),
            Edge(1, 3, 9),
            Edge(1, 2, 8),
            Edge(1, 4, 7),
            Edge(2, 4, 5),
            Edge(3, 4, 15),
            Edge(3, 5, 6),
            Edge(4, 5, 8),
            Edge(4, 6, 9),
            Edge(5, 6, 11)));
       int expected = 39;
       boolean verdict = totalWeight(edges)==expected;
			 System.out.println("verdict: "+verdict);
    }
}
