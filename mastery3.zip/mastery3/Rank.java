import java.util.*;

public class Rank {
    public static Long quickRank(TreeMap<Long, Integer> hist, int i) {
        long counter = 0;
        for (long j:hist.keySet()){
            counter+=hist.get(j);
            if (counter > i){
                return j;
            }else if (counter == i){
                counter += 1;
            }
        }
        return null;
    }
    public static void main(String[] args) {
        TreeMap<Long, Integer> input0 = new TreeMap<>();
        input0.put(1L, 5);
        input0.put(2L, 200);
        input0.put(3L, 7);
        Long expcted0 = 2L;

        TreeMap<Long, Integer> input1 = new TreeMap<>();
        input1.put(1L, 2);
        input1.put(2L, 5);
        input1.put(3L, 1);
        input1.put(4L, 9999);
        Long expcted1 = 4L;

        /*TreeMap<Long, Integer> input2 = new TreeMap<>();
        input1.put(1L, 9);
        input1.put(2L, 7);
        input1.put(3L, 6);
        input1.put(4L, 200);
        Long expcted2 = 3L;*/

        System.out.println("verdict: "+ (quickRank(input0, 100)==expcted0));
        System.out.println("verdict: "+ (quickRank(input1, 8)==expcted1));
        //System.out.println("verdict: "+ (quickRank(input2, 22)==expcted2));
    }
}
