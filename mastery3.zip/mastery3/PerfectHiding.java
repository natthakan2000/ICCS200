import java.util.*;
import graph.WeightedEdge;

public class PerfectHiding {
    public static int bestSpotDistance(int n, List<WeightedEdge> flights) {
        Set<Integer> ans = new HashSet<>();
        int tempt = 0;
        for (int i = 0; i<flights.size()-1; i+=2){
            if (flights.get(i).second == flights.get(i+1).first){
                ans.add(flights.get(i).cost);
                ans.add(flights.get(i+1).cost);
            }else{
                break;
            }
        }
        for (int i:ans){
            tempt += i;
        }
        System.out.println(tempt);
        return tempt;
    }




    public static WeightedEdge Edge(int u, int v, int c) {
        return new WeightedEdge(u, v, c);
    }

    public static void main(String[] args) {
        List<WeightedEdge> flights = new ArrayList<>(Arrays.asList(
								Edge(1, 4, 3),
								Edge(4, 2, 8),
								Edge(4, 3, 3),
								Edge(3, 5, 4),
								Edge(1, 6, 9),
								Edge(6, 7, 1)));
        int n = 7;
        int expcted = 11;
        boolean verdict = bestSpotDistance(n, flights)==expcted;
        System.out.println("verdict: "+verdict);
    }

}
