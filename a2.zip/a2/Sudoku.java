import java.util.HashSet;
import java.util.Set;

public class Sudoku {
    public static boolean sudokuSolved(int[][] grid) {
        Set<Integer> a = new HashSet<>();
        Set<Integer> b = new HashSet<>();
        Set<Integer> c = new HashSet<>();
        int correct = 0;
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[i].length; j++) {
                a.add(grid[i][j]);
                b.add(grid[j][i]);
            }
            if (a.size() == 9) {
                correct += 1;
            }
            if (b.size() == 9){
                correct += 1;
            }
            a.clear();
            b.clear();
        }
        for(int i = 0; i < grid.length-2; i+=3){
            for (int j = 0; j < grid.length-2; j+=3){
                c.add(grid[i][j]);
                c.add(grid[i][j+1]);
                c.add(grid[i][j+2]);
                c.add(grid[i+1][j]);
                c.add(grid[i+1][j+1]);
                c.add(grid[i+1][j+2]);
                c.add(grid[i+2][j]);
                c.add(grid[i+2][j+1]);
                c.add(grid[i+2][j+2]);
                if (c.size() == 9){
                    correct += 1;
                }c.clear();
            }
        }
        if (correct == 27){
            return true;
        }else{
            return false;
        }
    }
}
