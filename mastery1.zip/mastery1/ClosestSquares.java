import java.util.*;

public class ClosestSquares {
    public static long closestSquares(int[] a) {
        long ans = Long.MAX_VALUE;
        long d;
        for(int i = 0; i < a.length; i++){
            a[i] = Math.abs(a[i]);
        }
        Arrays.sort(a);
        for (int i = 0; i < a.length - 1; i++) {
            long x = a[i] * a[i];
            long y = a[i + 1] * a[i + 1];
            if (x > y){
                d = x - y;
            }else{
                d = y - x;
            }
            if (d < ans) {
                ans = d;
            }
        }
        return ans;
    }
}
