import java.util.*;

public class LostItems {
    public static int[] lostItems(int[] a, int b[]) {
        List<Integer> ans = new ArrayList<>();
        int[] cA = new int[16385];
        int[] cB = new int[16385];
        for (int i = 0; i < a.length; i++){
            cA[a[i]]++;
        }
        for (int i = 0; i < b.length; i++){
            cB[b[i]]++;
        }
        for(int i=0; i< cA.length;i++){
            if(!(cA[i]==cB[i])){
                ans.add(i);
            }
        }
        int[] f = new int[ans.size()];
        for (int i = 0; i < ans.size(); i++){
            f[i] = ans.get(i);
        }
        Arrays.sort(f);
        return f;
    }
}
