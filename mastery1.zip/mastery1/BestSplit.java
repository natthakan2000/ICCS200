public class BestSplit {
    public static int bestSplit(int[] a) {
        // todo: implement me
        int iS=0;
        long left = 0;
        long d;
        long total = 0;
        for (int i = 0; i < a.length; i++){
            total += a[i];
        }
        long min = Integer.MAX_VALUE;
        for(int i=0; i<a.length;i++){
            left +=a[i];
            d = (left - (total - left)) * (left - (total - left));
            if(d<min){
                min = d;
                iS = i+1;
            }
        }
        return iS;
    }
}
