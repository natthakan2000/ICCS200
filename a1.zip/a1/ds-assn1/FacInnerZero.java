import java.math.BigInteger;

public class FacInnerZero {
  public static int zeroInsideFac(int n){
    int ans = 0; //ans equals to zero
    String convert = ""; //String of the BigInteger after removing zero at the back
    BigInteger counter = BigInteger.valueOf(1); //create a variable called counter which start from 1
    BigInteger current = BigInteger.valueOf(1); //create a current which will keep the values while multiplying
    BigInteger p = BigInteger.valueOf(n); // Make n as a BigInteger
    BigInteger i = BigInteger.valueOf(2); //Create a variable name i, which start from 2 (for factorial)
    if (n == 0 || n == 1){ //factorial of 0 and 1 will get into this loop
      ans=0; //make answer = 0 because factorial of 0 and 1 is 1
    }
    while(counter.compareTo(p) == -1){ //while counter less than the number given
      current = current.multiply(i); //multiplay the number as factorial is n*(n-1)
      i = i.add(BigInteger.ONE); //add i to
      counter = counter.add(BigInteger.ONE); //increase counter by one
    }
    while (current.mod(BigInteger.TEN).equals(BigInteger.ZERO)){//Remove zero at the end of the number
      current = current.divide(BigInteger.TEN);
    }
    convert = current.toString(); //convert integer to string
    for (int j = 0; j < convert.length(); j++){ //loop through to check the total number of zero inside fac
      if (convert.charAt(j) == '0'){ //check if a character in string equal 0
        ans += 1; //increase ans (which works as a counter) by one
      }
    }
    return ans; //return the total number zero
  }
}
