import java.util.Arrays;

public class HalvingSum {
  public static double hsum(double[] X) {
    while(X.length != 1) { //When array X have length of 1 get out of the loop
      double[] Y = new double[X.length / 2]; //Allocate Y to halve of the length of array X
      for (int i = 0; i < X.length / 2; i++) { //add index i by 1 every time it get in the while loop
        Y[i] = X[2 * i] + X[2 * i + 1]; //add each pair and add it to array Y
      }
      X = Arrays.copyOf(Y,Y.length); //Make array X into Y
    }
    return X[0]; //return the sum of the array
  }
}
