
public class MinMax {
  public static double minMaxAverage(int[] numbers) {
    int counter = 0;
    int myMax = 0;
    int myMin = 0;
    if (numbers.length != 0 && numbers.length%2 == 0){
      int[] max = new int[numbers.length / 2];
      int[] min = new int[numbers.length / 2];
      for (int i = 0; i < numbers.length; i+=2){
        if (numbers[i] > numbers [i+1]){
          max[counter] = numbers[i];
          min[counter] = numbers[i+1];
        }else{
          max[counter] = numbers[i+1];
          min[counter] = numbers[i];
        }
        counter += 1;
      }
      myMax = max[0];
      myMin = min[0];
      for (int i = 1; i < max.length; i++){
        if (myMax < max[i]){
          myMax = max[i];
        }
        if (myMin > min[i]) {
          myMin = min[i];
        }
      }
    }else{
      int[] max = new int[numbers.length / 2 + 1];
      System.out.println(max.length);
      int[] min = new int[numbers.length / 2 + 1];
      for (int i = 0; i < numbers.length-1; i+=2){
        if (numbers[i] > numbers[i+1]){
          max[counter] = numbers[i];
          min[counter] = numbers[i+1];
        }else{
          max[counter] = numbers[i+1];
          min[counter] = numbers[i];
        }
        counter += 1;
      }
      max[numbers.length/2] = numbers[numbers.length-1];
      min[numbers.length/2] = numbers[numbers.length-1];
      myMax = max[0];
      myMin = min[0];
      for (int i = 1; i < max.length; i++){
        if (myMax < max[i]){
          myMax = max[i];
        }
        if (myMin > min[i]) {
          myMin = min[i];
        }
      }
    }
    return (myMax+myMin)/2.0;
  }
}}