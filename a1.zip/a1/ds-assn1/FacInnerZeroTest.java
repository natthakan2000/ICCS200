public class FacInnerZeroTest {
  public static void main(String[] args) {
      assert 0 == FacInnerZero.zeroInsideFac(0);
  }
}
