import java.util.*;

public class KStacks {
    public static int maximizeScore(List<Stack<Integer>> S, int x) {
        PriorityQueue<Stack<Integer>> q = new PriorityQueue<Stack<Integer>>(Comparator.comparing(Stack::peek));
        int sum = 0;
        int counter = 0;
        for (int i = 0; i < S.size(); i++){
            q.add(S.get(i));
        }
        while (sum <= x){
            if (q.peek() != null) {
                Stack<Integer> nS = q.poll();
                sum += nS.pop();
                if(sum > x){
                    counter -= 1;
                }
                if (!nS.isEmpty()){
                    q.add(nS);
                }
                counter ++;
            }
        }
        return counter;
    }

    // Convenient class (you can but don't need to use it.)
    static class StackBuilder<T> {
        private Stack<T> stk;
        public StackBuilder() { this.stk = new Stack<>(); }

        public StackBuilder<T> push(T elt) {
            stk.push(elt);
            return this;
        }
        public Stack<T> build() { return stk; }
    }
    // To use the StackBuilder, you write, for example,
    //    new StackBuilder<Integer>().push(6).push(3).push(1).build()
    //  This will make a stack and push these elements into the stack in that order.
    //  The build() command at the end returns the final stack.
}
