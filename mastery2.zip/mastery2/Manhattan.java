import java.util.*;

public class Manhattan {
    public static int distanceFromStart(String moves) {
        long x = 0;
        long y = 0;
        for (int i = 0; i < moves.length(); i++){
            if (moves.charAt(i) == 'N'){
                y += 1;
            }else if (moves.charAt(i) == 'S'){
                y -= 1;
            }else if (moves.charAt(i) == 'E'){
                x += 1;
            }else {
                if (moves.charAt(i) == 'W'){
                    x -= 1;
                }
            }
        }
        return (int) (Math.abs(x) + Math.abs(y)); // TODO: fix me
    }
}
