import java.util.*;

public class ParenMatcher {

    public static int[] match(String ex) {
        int[] a = new int[ex.length()];
        //int[] c = new int[ex.length()];
        //Stack<Character> s1 = new Stack<>();
        Stack<Integer> s2 = new Stack<>();
        int counter = 0;
        char[] b = ex.toCharArray();
        for(int i = 0 ; i < ex.length(); i++){
            if (b[i] == '('){
                s2.add(i);
            }else{
                if (!s2.isEmpty()) {
                    //s1.pop();
                    int count = s2.pop();
                    counter = i - count;
                    a[count] = counter;
                    a[i] = -counter;
                }
            }
        }
        return a;
    }
}
