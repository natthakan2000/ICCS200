import java.util.*;

public class Count {
    public static int count(int[] xs, int k) {
        int low = 0;
        int high = xs.length;
        int x = helper(low, high, k ,xs);
        int i = 0;
        while (xs[i] != k){
            if (xs[i] > k){
                i = 1;
                break;
            }
            i++;
        }
        return x-i;
    }
    public static int helper(int low, int high, int k, int[]xs){
        if (low == high){
            return low;
        }else{
            int mid = (low+high)/2;
            if (xs[mid] <= k) {
                return helper(mid + 1, high, k, xs);
            }
            else{
                return helper(low, mid, k,xs);
            }
        }
    }
}
