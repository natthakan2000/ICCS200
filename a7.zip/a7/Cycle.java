import java.util.*;
//Collaborators: Parm
public class Cycle {
    public static List<String> findCycle(ArrayList<Pair<String, String>> graph) {
        HashMap<String, HashSet<String>> adjacentTable = new HashMap<>();
        HashSet<String> visited = new HashSet<>();
        LinkedList<String> pattern = new LinkedList<>();
        for (Pair<String, String> i : graph) {
            if (!adjacentTable.containsKey(i.first)) {
                HashSet<String> element = new HashSet<>();
                element.add(String.valueOf(i.second));
                adjacentTable.put(i.first, element);
            } else {
                HashSet<String> truth = adjacentTable.get(i.first);
                truth.add(String.valueOf(i.second));
            }
        }
        Set<String> vertices = adjacentTable.keySet();
        vertices.removeAll(visited);
        for (String parent : vertices){
            dfs(adjacentTable, pattern, visited, parent);
        }
        if (pattern.isEmpty()){
            return null;
        }
        return pattern;
    }
    private static LinkedList<String> dfs(HashMap<String, HashSet<String>> set, LinkedList<String> list, HashSet<String> visited, String node) {
        if (!visited.contains(node)) {
            list.add(node);
            visited.add(node);
            for (String i : set.get(node)) {
                if (!i.equals(node)) dfs(set, list, visited, i);
            }
            list.remove(list.size()-1);
        } else {
            return list;
        }
        return list;
    }
}