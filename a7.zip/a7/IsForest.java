import java.util.*;
//Collaborators: Parm
public class IsForest {
    static class CycleDetection{
        public int edges = 0;
    }
    static Set<Integer> nbrsExcluding(Set<Integer>[] G, Set<Integer> vtxes, Set<Integer> excl, CycleDetection state) {
        Set<Integer> union = new TreeSet<>();
        for (Integer src : vtxes) {
            for (Integer dst : G[src])
                if (!excl.contains(dst)) {
                    union.add(dst);
                    state.edges++;
                }else {
                    state.edges++;
                }
        }
        return union;
    }
    static Set<Integer> bfs(Set<Integer>[]  graph, int s , Set<Integer> beenVisited, CycleDetection state) {
        Set<Integer> floor = new TreeSet<>(Collections.singletonList(s)); //Array.asList
        beenVisited.add(s);
        while (!floor.isEmpty()) {
            floor = nbrsExcluding(graph, floor, beenVisited, state);
            beenVisited.addAll(floor);
        }
        return beenVisited;
    }
    public static int identifyTrees(int n, Iterable<Pair<Integer, Integer>> edges){
        Set<Integer>[] graph = new TreeSet[n];
        Arrays.fill(graph, new TreeSet<>());
        Iterator<Pair<Integer, Integer>> edgeIterator = edges.iterator();
        CycleDetection cycleDetection = new CycleDetection();
        Set<Integer> beenVisited = new TreeSet<>();
        int counter = 0;
        while(edgeIterator.hasNext()){
            Pair<Integer, Integer> currentEdge = edgeIterator.next();
            graph[currentEdge.first].add(currentEdge.second);
            graph[currentEdge.second].add(currentEdge.first);
        }
        for (int i = 0; i < n ; i++) {
            if(beenVisited.contains(i)){
                continue;
            }
            Set<Integer> traversal = bfs(graph, i, beenVisited, cycleDetection);
            if(!traversal.isEmpty()){
                counter++;
            }
            if(cycleDetection.edges >= traversal.size()*2){ return 0; }
            else cycleDetection.edges = 0;
        }
        return counter;
    }
}