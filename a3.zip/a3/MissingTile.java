//Collaborator P Pao, Harvey, Taem
public class MissingTile {
  public static void tileGrid(Grid board) {
    tileHelper(board,board.getPaintedCellX(),board.getPaintedCellY(), board.size(),0,0);
  }
  static void tileHelper(Grid board, int paintX, int paintY, int size, int preX, int preY){
    if (size == 1){
      return;
    }
    if (size == 2){
      if (paintX == preX + 1  && paintY == preY + 1){
        board.setTile(preX + 1,preY + 1,1);
      }else if (paintX == preX && paintY == preY){
        board.setTile(preX,preY,3);
      }else if (paintX == preX+ 1 && paintY == preY){
        board.setTile(preX + 1,preY,0);
      }else{
        board.setTile(preX,preY + 1,2);
      }
    }else{
      size = size/2;
      if (paintX >= size + preX && paintY >= size +preY) {
        board.setTile(preX + size, preY + size, 1);
        tileHelper(board,preX + size-1, preY + size-1,size,preX ,preY);
        tileHelper(board,preX + size, preY + size-1,size,preX + size, preY);
        tileHelper(board,preX + size -1,preY + size,size, preX, preY + size);
        tileHelper(board,paintX, paintY,size,preX + size,preY + size);
      } else if (paintX < size + preX && paintY >= size +preY) {
        board.setTile(preX + size -1, preY + size, 2);
        tileHelper(board,preX + size-1, preY + size-1,size,preX,preY);
        tileHelper(board,preX + size, preY + size-1,size, preX + size, preY);
        tileHelper(board,paintX,  paintY,size, preX, preY+size);
        tileHelper(board,preX + size, preY + size,size,preX + size, preY + size);
      } else if (paintX < size + preX && paintY < size + preY) {
        board.setTile(preX + size - 1, preY + size - 1, 3);
        tileHelper(board,paintX, paintY,size,preX,preY);
        tileHelper(board,preX + size, preY + size-1,size, preX + size, preY);
        tileHelper(board,preX + size -1,preY + size,size, preX, preY + size);
        tileHelper(board,preX + size, preY + size,size,preX + size, preY + size);
      } else {
        board.setTile(preX + size , preY + size - 1, 0);
        tileHelper(board,preX + size-1, preY + size-1,size,preX,preY);
        tileHelper(board,paintX , paintY,size,preX+size,preY);
        tileHelper(board,preX + size -1,preY + size,size, preX, preY + size);
        tileHelper(board,preX + size, preY + size,size,preX + size, preY + size);
      }
    }
  }
}