import java.util.Arrays;

public class Midway {
    public static long hanoiHelper(int[] diskPos, int startPeg, int targetPeg, int auxPeg){
        if (diskPos.length == 0){
            return 0;
        }else{
            if (diskPos[diskPos.length-1] == targetPeg){
                return (hanoiHelper(Arrays.copyOfRange(diskPos,0,diskPos.length-1), auxPeg, targetPeg, startPeg));
            }
            else{
                return (long) (hanoiHelper(Arrays.copyOfRange(diskPos,0,diskPos.length-1), startPeg, auxPeg, targetPeg) + Math.pow(2,diskPos.length-1));
            }
        }
    }
    public static long stepsRemaining(int[] diskPos){
        return hanoiHelper(diskPos, 0, 1, 2);
    }
}
