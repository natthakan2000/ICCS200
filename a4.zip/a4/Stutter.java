public class Stutter {
    //collaborator Taem, Harvey , Parm;
    public static boolean isSubstr(String a, String b){
        int counter = 0; //O(1)
        if (a.length() == 0){
            return true;
        }
        for (int i = 0; i < b.length(); i++){ //(worst case: O(len(a) + len(b))
            if (a.charAt(counter) == b.charAt(i)){ //O(1)
                counter++; //O(1)
            }
            if (counter == a.length()){ //O(1)
                return true; //O(1)
            }
        }
        return false; //O(1)
    } //= O(len(b))
    public static String stutter(String A, int k){
        StringBuilder s = new StringBuilder(""); //Intellij told me to use and P France says it is faster than using String;
        for(int i = 0; i < A.length(); i++){
            for(int j = 0; j < k; j++){//O(nk)
                s.append(A.charAt(i)); //O(1)
            }
        }
        return s.toString(); //O(n) O(kn)
    }
    public static int maxStutter(String a, String b){
        int m = b.length(); //O(1)
        int n = a.length(); //O(1)
        int k = m/n; //O(1)
        return helper(a,b,0,k+1);
    }
    public static int helper(String a, String b, int low, int up){
        if(low-up>=-1){
            return low;
        }
        else {
            if(isSubstr(stutter(a,(low+up)/2),b)){
                return helper(a,b,(low+up)/2, up);
            }
            else return helper(a,b,low,(low+up)/2 );
        }
    }
}
