public class Last {
    //collaborators Harvey, Parm
    public static Integer binarySearchLast(int[] a, int k) {
        return helper(a, 0, a.length-1, k,-1);
    }
    static Integer helper(int[] a, int low, int high, int k, int i) {

        if (low > high){
            if(i==-1){
                return null;
            }
            return i;
        }
        else {
            int middle = (low+high)/2;
            if (a[middle]==k) {
                i = middle;
                return helper(a, middle+1, high, k,i);
            }
            else if (k < a[middle]) {
                return helper(a, low, middle-1, k,i);
            }
            else {
                return helper(a, middle+1, high, k,i);
            }
        }
    }
}