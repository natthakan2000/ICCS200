//Collaborators: P pao, Taem
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Uproot {
    public static HashMap<Integer, Integer> treeToParentMap(BinaryTreeNode T){
        HashMap<Integer,Integer> map = new HashMap<>();
        treeToParentMapHelper(map, T, null);
        return map;
    }
    public static void treeToParentMapHelper(HashMap<Integer,Integer> map, BinaryTreeNode T,  Integer parent){
        if(T != null){
            if (parent == null){
                treeToParentMapHelper(map, T.left, T.key);
                treeToParentMapHelper(map, T.right, T.key);
            }else{
                map.put(T.key, parent);
                treeToParentMapHelper(map, T.left, T.key);
                treeToParentMapHelper(map, T.right, T.key);
            }
        }
    }
    public static BinaryTreeNode parentMapToTree(Map<Integer, Integer> map){
        Map<Integer, ArrayList<Integer>> swap = new HashMap<>();
        swap = swappingMap(map,swap);
        int root = 0;
        for (int i : map.keySet()){
            if (!map.containsKey(map.get(i))){
                root = map.get(i);
            }
        }
        System.out.println(swap);
        BinaryTreeNode T = new BinaryTreeNode(root);
        return parentMapToTreeHelper(root, swap, T);
    }
    public static Map<Integer, ArrayList<Integer>> swappingMap(Map<Integer, Integer> map, Map<Integer,ArrayList<Integer>> swap){
        for (Map.Entry<Integer, Integer> i : map.entrySet()){
            Integer key = i.getKey();
            Integer value = i.getValue();
            if (!swap.containsKey(value)){
                ArrayList<Integer> arrayList = new ArrayList<>();
                arrayList.add(key);
                swap.put(value, arrayList);
            }else{
                swap.get(value).add(key);
            }
        }
        return swap;
    }
    public static BinaryTreeNode parentMapToTreeHelper(int key, Map<Integer,ArrayList<Integer>> swap, BinaryTreeNode T){
        ArrayList<Integer> arrayList = swap.get(key);
        if (!swap.containsKey(key)){
            return new BinaryTreeNode(key);
        }else{
            if (arrayList.size() == 2){
                int left = arrayList.get(0);
                int right = arrayList.get(1);
                T.left = new BinaryTreeNode(left);
                T.right = new BinaryTreeNode(right);
                parentMapToTreeHelper(left, swap, T.left);
                parentMapToTreeHelper(right, swap, T.right);
            }else if (arrayList.size() == 1){
                int left = arrayList.get(0);
                T.left = new BinaryTreeNode(left);
                parentMapToTreeHelper(left, swap, T.left);
            }
        return T;
        }
    }
}
