//Collaborators: Vicky
import java.util.Arrays;

public class MakeTree {
    public static BinaryTreeNode buildBST(int[] keys){//let n be keys.length
        Arrays.sort(keys); //O(nlogn)
        int m = keys.length/2; //o(1)
        return new BinaryTreeNode(buildBSThelper(keys, 0, m-1), keys[m], buildBSThelper(keys, m+1, keys.length-1));//call T(n/2)
    }//2T(n/2) + O(nlogn) + O(1), = 2 * O(logn) + O(nlogn), = O(nlogn)
    public static BinaryTreeNode buildBSThelper(int[] keys, int low, int high){
        if (low == high){
            return new BinaryTreeNode(keys[(low+high)/2]);
        }else{
            int m = (low + high)/2;
            if (low > m-1){
                return new BinaryTreeNode(null, keys[m], buildBSThelper(keys, m+1, high));
            }else if(m+1 > high){
                return new BinaryTreeNode(buildBSThelper(keys, low, m-1), keys[m], null);
            }
            return new BinaryTreeNode(buildBSThelper(keys, low, m-1), keys[m], buildBSThelper(keys, m+1, high));
        }
    }
}
