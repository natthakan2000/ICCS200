//Collaborators: Taem
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Decor{
    public static BinaryTreeNode mkTree(List<Integer> postOrder, List<Integer> inOrder){ //Aj Boy says no need for helper function
        if(postOrder.size()==0){
            return null ;
        }
        else {
            int key = postOrder.get(postOrder.size()-1);
            BinaryTreeNode T = new BinaryTreeNode(key);
            int nextRootI = inOrder.indexOf(key);
            if (nextRootI>=0) {
                List<Integer> leftPostOrder = postOrder.subList(0, nextRootI);
                List<Integer> rightPostOrder = postOrder.subList(nextRootI, postOrder.size() -1);
                List<Integer> leftInOrder = inOrder.subList(0, nextRootI);
                List<Integer> rightInOrder = inOrder.subList(nextRootI+1,inOrder.size());
                if(leftPostOrder.size()>0&&rightPostOrder.size()>0&&leftInOrder.size()>0&&rightInOrder.size()>0) {
                    T.left = mkTree(leftPostOrder, leftInOrder);
                    T.right = mkTree(rightPostOrder, rightInOrder);
                }
                else if(leftPostOrder.size()>0&&leftInOrder.size()>0){
                    T.left = mkTree(leftPostOrder, leftInOrder);
                }
                else {
                    T.right = mkTree(rightPostOrder, rightInOrder);
                }
            }
            return T;
        }
    }
}
